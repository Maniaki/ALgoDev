package testJavafx;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.jar.Attributes.Name;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Main extends Application{


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}
	
	@Override
    public void start(Stage stage) throws Exception {
		Grille_Sudoku grille = new Grille_Sudoku();
		//creation d'une grille
		Text text2 = new Text();
		GridPane grid = new GridPane();
		
		grid.setGridLinesVisible(true);
		for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
            	TextField name = new TextField();
            	name.setMaxSize(40, 40);
            	name.setText(String.valueOf(grille.matrice[i][j]));
                  grid.add(name,i,j);
}
}
		
	    grid.setScaleX(1);
	    grid.setScaleY(1);
	    grid.setScaleZ(1);	    
		
		grid.resizeRelocate(200,150 , 400, 400);
	/*	//creation d'un path Tab
		Path path = new Path();
		
		MoveTo moveTo = new MoveTo(200,100) ;
		
		LineTo line1 = new LineTo(200,500);
		
		LineTo line2 = new LineTo(600,500);
		
		LineTo line3 = new LineTo(600,100);
		
		LineTo line4 = new LineTo(200,100);
		
		
		
		LineTo line5 = new LineTo(200,140);
		
		path.getElements().add(moveTo);
		path.getElements().addAll(line1,line2,line3,line4);
		*/
		//Texte en haut
		
		Text text1 = new Text();
		//Taille du texte 
		text1.setFont(new Font(45));
		
		//zone ou le texte est afficher
		text1.setX(235);
		text1.setY(40);
		
		//couleur texte
		text1.setFill(Color.YELLOW);
		
		//ajouter bordure et couleur bordure texte
		
		text1.setStrokeWidth(2);
		text1.setStroke(Color.BLUE);
		
		//contenu du texte
		text1.setText("LE SUDOKU LETTRE");
		
		//cree un bouton 
	      Button sauvegarder= new Button("Sauvegarder"); 
	      sauvegarder.setLayoutX(150); 
	      sauvegarder.setLayoutY(550); 
	      
	      Button verifier= new Button("V�rification"); 
	      verifier.setLayoutX(400); 
	      verifier.setLayoutY(550); 
	      
	      Button quitter= new Button("Quitter"); 
	      quitter.setLayoutX(650); 
	      quitter.setLayoutY(550); 
	      
	      Button newParty= new Button("Nouvelle Partie"); 
	      newParty.setLayoutX(650); 
	      newParty.setLayoutY(150); 
	      
	      Button charger= new Button("Charger"); 
	      charger.setLayoutX(650); 
	      charger.setLayoutY(250); 
	      
	      
	      sauvegarder.setOnMouseClicked((new EventHandler<MouseEvent>() {
	    	  public void handle(MouseEvent event)
	    	  {
	    		  /// on recup dans un evenement 
	    		 int j=0;
	    		  int i=0;
	    		  for( Node node: grid.getChildren()) {

	                    if(( node instanceof TextField)&&((i!=8)&&(j!=8))&&(((TextField) node).getText()).isEmpty()==false) {
	                    	
	                       grille.matrice[i][j]=((TextField) node).getText().charAt(0);
	                       System.out.println(grille.matrice[i][j]);
	                       j=(j+1)%9;
	                       if(j==0)
	                       {
	                    	   i=(i+1);
	                    	   
	                       } 
	                    
	                }
	    		  }
	    	  File outFile = new File("SudokuSave.fic");
				try {
					FileOutputStream outFileStream = new FileOutputStream(outFile);
					ObjectOutputStream outObjectStream = new ObjectOutputStream(outFileStream);
					outObjectStream.writeObject(grille);
					outObjectStream.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				//faire les modifs 
				
				
				 text2.setFont(new Font(25));
   			  text2.setX(300);
   			  text2.setY(500);
				  text2.setText("Sauvegard�");
				
	    	  }
	      }));
	      
	      verifier.setOnMouseClicked((new EventHandler<MouseEvent>(){
	    	  public void handle(MouseEvent event) {
	    		  int j=0;
	    		  int i=0;
	    		  for( Node node: grid.getChildren()) {

	                    if(( node instanceof TextField)&&((i!=8)&&(j!=8))&&(((TextField) node).getText()).isEmpty()==false) {
	                    	
	                       grille.matrice[i][j]=((TextField) node).getText().charAt(0);
	                       System.out.println(grille.matrice[i][j]);
	                       j=(j+1)%9;
	                       if(j==0)
	                       {
	                    	   i=(i+1);
	                    	   
	                       } 
	                    
	                }
	    		  }
	    		  if(grille.est_fini()==true)
	    		  {
	    			  if(grille.verifie_unicite()==true)
	    			  {
	    				  text2.setFont(new Font(25));
		    			  text2.setX(300);
		    			  text2.setY(500);
	    				  text2.setText("Vous avez Gagn�");
	    				  
	    			  }
	    			  else
	    			  {
	    				  text2.setFont(new Font(25));
		    			  text2.setX(255);
		    			  text2.setY(500);
	    				  text2.setText("Vous n'avez pas la bonne solution");
	    				  
	    			  }
	    		  }else
	    		  {
	    			  text2.setFont(new Font(25));
	    			  text2.setX(300);
	    			  text2.setY(500);
	    			  text2.setText("Vous n'avez pas fini");
	    			  
	    		  }
	    	  }
	      }));
	      
	      quitter.setOnMouseClicked((new EventHandler<MouseEvent>(){
	    	  public void handle(MouseEvent event) {
	    		  System.out.println("Au revoir");
	    		  stage.close();
	    	  }
	      }));
		
	     newParty.setOnMouseClicked((new EventHandler<MouseEvent>(){
	    	  public void handle(MouseEvent event) {
	    		  grille.initializeGrid();
	    		  grille.nouvelle_grille();
	    		  for(int k = 0;k<9;k++)
	    		  {
	    			  for(int l = 0; l<9;l++)
	    			  {
	    				  TextField name = new TextField();
	    				  name.setMaxSize(40, 40);
	    				  name.setText(String.valueOf(grille.matrice[k][l]));
	    				 
	    					name.setEditable(!grille.mat2[k][l]);
	    					 grid.add(name,k,l);
	    					 
	    				 
	    			  }
	    		  }
	    	  }
	      }));
		
	     charger.setOnMouseClicked((new EventHandler<MouseEvent>(){
	    	  public void handle(MouseEvent event) {
	    		  
	    		  
	    		  
	  			
					// Charger partie sauvegarder
					try {
					FileInputStream inFileStream;
					File inFile = new File("SudokuSave.fic");
					inFileStream = new FileInputStream(inFile);
					ObjectInputStream inObjectStream = new ObjectInputStream(inFileStream);
					Grille_Sudoku grille2 = (Grille_Sudoku) inObjectStream.readObject();
					grille.charger_grille(grille2);
					inObjectStream.close();
					for(int k = 0;k<9;k++)
		    		  {
		    			  for(int l = 0; l<9;l++)
		    			  {
		    				  TextField name = new TextField();
		    				  name.setMaxSize(40, 40);
		    				  name.setText(String.valueOf(grille.matrice[k][l]));
		    				 
		    					name.setEditable(!grille.mat2[k][l]);
		    					 grid.add(name,k,l);
		    					 
		    				 
		    			  }
		    		  }
					text2.setFont(new Font(25));
	    			  text2.setX(300);
	    			  text2.setY(500);
	    			  text2.setText("Vous avez charg� la partie");
					
					}catch ( Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
					
	    	    
					 
	    	  }}));
		
		Group root = new Group();

		//Retrieving the observable list object 
		//liste qu contient les btn et les textes
	      ObservableList list = root.getChildren(); 
	       
	      //Setting the text object as a node to the group object 
	      list.add(text1); 
	      list.add(sauvegarder);
	      list.add(verifier);
	      list.add(quitter);
	      list.add(newParty);
	      list.add(charger);
	      list.add(text2);
		
	     list.add(grid);
	     
	     //creation de la scene
        Scene scene = new Scene(root,800,600);
        scene.setFill(Color.LAVENDER);  

        stage.setScene(scene);
        stage.setTitle("Le Sudoku Lettre");
        stage.setResizable(false);
       
        stage.show();
    }

}
