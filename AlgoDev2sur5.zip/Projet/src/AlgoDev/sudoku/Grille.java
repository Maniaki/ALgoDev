package AlgoDev.sudoku;

import java.io.Serializable;

public class Grille implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int nbColonne;
	private int nbLigne;
	private char[][] matrice = new char[nbLigne][nbColonne];
	
	public Grille(int nbColonne, int nbLigne)
	{
		this.setNbLigne(nbLigne);
		this.setNbColonne(nbColonne);
		char[][] _matrice = new char[nbLigne][nbColonne];
		for(int i = 0; i < nbLigne; i++)
		{
			for(int j = 0; j < nbColonne; j++)
			{
					_matrice[i][j] = '0';
			}
		}
		this.setMatrice(_matrice);
	}
	
	public Grille(int nbColonne, int nbLigne, char matrice[][])
	{
		this.setNbColonne(nbColonne);
		this.setNbLigne(nbLigne);
		this.setMatrice(matrice);
	}

	public int getNbColonne() {
		return nbColonne;
	}

	public void setNbColonne(int nbColonne) {
		this.nbColonne = nbColonne;
	}

	public int getNbLigne() {
		return nbLigne;
	}

	public void setNbLigne(int nbLigne) {
		this.nbLigne = nbLigne;
	}

	public char[][] getMatrice() {
		return matrice;
	}

	public void setMatrice(char[][] matrice) {
		this.matrice = matrice;
	}
	
	// Methode
	
	void afficherGrille(int nbLigne, int nbColonne)
	{
		for(int i = 0; i < nbLigne; i++)
		{
			for(int j = 0; j < nbColonne; j++)
			{
				System.out.println(matrice[i][j]);
			}
		}
	}
	
	void afficherGrille()
	{
		int nbLigne = this.nbLigne;
		int nbColonne = this.nbColonne;
		for(int i = 0; i < nbLigne; i++)
		{
			for(int j = 0; j < nbColonne; j++)
			{
				System.out.println(matrice[i][j]);
			}
		}
	}
		
}
