package AlgoDev.sudokuLettre;

import java.io.Serializable;

import AlgoDev.sudoku.GrilleSudoku;

public class GrilleSudokuLettre extends GrilleSudoku implements Serializable{

	private static final long serialVersionUID = 1L;
	
	public GrilleSudokuLettre(int nbColonne, int nbLigne) {
		super(nbColonne, nbLigne);
		// TODO Auto-generated constructor stub
	}
	
	public GrilleSudokuLettre(char[][] matrice) {
		super(matrice);
		// TODO Auto-generated constructor stub
	}

	public boolean unicite_ligne() // verifie s'il n'y a pas de doublons en ligne
	{
		boolean[] tab = new boolean[9];


		for(int i = 0;i<=8;i++)
		{
			for(int j = 0; j<=8;j++)
			{
				tab[j]=false;
			}
			for ( int k = 0; k<=8;k++)
			{
				switch(this.getMatrice()[i][k])
				{
				case 'A':
				{
					if (tab[0]== true)
					{
						return false;
					}
					else
					{
						tab[0]= true;
					}
					break;
				}
				case 'B':
				{
					if (tab[1]== true)
					{
						return false;
					}
					else
					{
						tab[1]= true;
					}
					break;
				}
				case 'C':
				{
					if (tab[2]== true)
					{
						return false;
					}
					else
					{
						tab[2]= true;
					}
					break;
				}
				case 'D':
				{
					if (tab[3]== true)
					{
						return false;
					}
					else
					{
						tab[3]= true;
					}
					break;
				}
				case 'E':
				{
					if (tab[4]== true)
					{
						return false;
					}
					else
					{
						tab[4]= true;
					}
					break;
				}
				case 'F':
				{
					if (tab[5]== true)
					{
						return false;
					}
					else
					{
						tab[5]= true;
					}
					break;
				}
				case 'G':
				{
					if (tab[6]== true)
					{
						return false;
					}
					else
					{
						tab[6]= true;
					}
					break;
				}
				case 'H':
				{
					if (tab[7]== true)
					{
						return false;
					}
					else
					{
						tab[7]= true;
					}
					break;
				}
				case 'I':
				{
					if (tab[8]== true)
					{
						return false;
					}
					else
					{
						tab[8]= true;
					}
					break;
				}
				default :
				{
					return false;
				}
				}
			}
		}
		return true;
	}

	public boolean unicite_colonne() // Verifie si pas de doublons en colonne
	{
		boolean[] tab = new boolean[9];

		int i,j,k;

		for( i = 0;i<=8;i++)
		{
			for( j = 0; j<=8;j++)
			{
				tab[j]=false;
			}
			for ( k = 0; k<=8;k++)
			{
				switch(this.getMatrice()[k][i])
				{
				case 'A':
				{
					if (tab[0]== true)
					{
						return false;
					}
					else
					{
						tab[0]= true;
					}
					break;
				}
				case 'B':
				{
					if (tab[1]== true)
					{
						return false;
					}
					else
					{
						tab[1]= true;
					}
					break;
				}
				case 'C':
				{
					if (tab[2]== true)
					{
						return false;
					}
					else
					{
						tab[2]= true;
					}
					break;
				}
				case 'D':
				{
					if (tab[3]== true)
					{
						return false;
					}
					else
					{
						tab[3]= true;
					}
					break;
				}
				case 'E':
				{
					if (tab[4]== true)
					{
						return false;
					}
					else
					{
						tab[4]= true;
					}
					break;
				}
				case 'F':
				{
					if (tab[5]== true)
					{
						return false;
					}
					else
					{
						tab[5]= true;
					}
					break;
				}
				case 'G':
				{
					if (tab[6]== true)
					{
						return false;
					}
					else
					{
						tab[6]= true;
					}
					break;
				}
				case 'H':
				{
					if (tab[7]== true)
					{
						return false;
					}
					else
					{
						tab[7]= true;
					}
					break;
				}
				case 'I':
				{
					if (tab[8]== true)
					{
						return false;
					}
					else
					{
						tab[8]= true;
					}
					break;
				}
				default :
				{
					return false;
				}
				}
			}
		}
		return true;
	}

	public boolean unicite_Region(int l, int c)
	{
		boolean tab2[] = new boolean[9];
		for(int t = 0; t<=8;t++)
		{
			tab2[t]=false;
		}
		for (int i = l;i<=l+2;i++)
		{
			for(int j= c;j<=c+2;j++)
			{
				switch(this.getMatrice()[i][j])
				{
				case 'A':
				{
					if (tab2[0]== true)
					{
						return false;
					}
					else
					{
						tab2[0]= true;
					}
					break;
				}
				case 'B':
				{
					if (tab2[1]== true)
					{
						return false;
					}
					else
					{
						tab2[1]= true;
					}
					break;
				}
				case 'C':
				{
					if (tab2[2]== true)
					{
						return false;
					}
					else
					{
						tab2[2]= true;
					}
					break;
				}
				case 'D':
				{
					if (tab2[3]== true)
					{
						return false;
					}
					else
					{
						tab2[3]= true;
					}
					break;
				}
				case 'E':
				{
					if (tab2[4]== true)
					{
						return false;
					}
					else
					{
						tab2[4]= true;
					}
					break;
				}
				case 'F':
				{
					if (tab2[5]== true)
					{
						return false;
					}
					else
					{
						tab2[5]= true;
					}
					break;
				}
				case 'G':
				{
					if (tab2[6]== true)
					{
						return false;
					}
					else
					{
						tab2[6]= true;
					}
					break;
				}
				case 'H':
				{
					if (tab2[7]== true)
					{
						return false;
					}
					else
					{
						tab2[7]= true;
					}
					break;
				}
				case 'I':
				{
					if (tab2[8]== true)
					{
						return false;
					}
					else
					{
						tab2[8]= true;
					}
					break;
				}
				default :
				{
					return false;
				}
				}
			}
		}
		return true;
	}

	public boolean verifie_unicite()
	{
		if(unicite_ligne() == false)
		{
			return false;
		}
		if(unicite_colonne() == false)
		{
			return false;
		}
		for(int i = 0;i<9;i=i+3)
		{
			for(int j=0;j<9;j=j+3)
			{
				if(unicite_Region(i,j)==false)
				{
					return false;
				}
			}
		}
		return true;

	}

}
