package AlgoDev.Menu;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class MenuFx extends Application{

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}
	
	@Override
    public void start(Stage stage) throws Exception {
		
		Text text1 = new Text();
		text1.setFont(new Font(45));
		text1.setX(235);
		text1.setY(40);
		text1.setFill(Color.YELLOW);
		text1.setStrokeWidth(1);
		text1.setStroke(Color.BLUE);
		text1.setText("MENU PRINCIPAL");
		
		
		Button quitter= new Button("Quitter"); 
	      quitter.setLayoutX(350); 
	      quitter.setLayoutY(450); 
	      quitter.setScaleX(10);
	      quitter.setScaleY(5);
	      
	      Button jouer = new Button("Jouer"); 
	      jouer.setLayoutX(350); 
	      jouer.setLayoutY(250); 
	      jouer.setScaleX(12);
	      jouer.setScaleY(5);
	      
	      quitter.setOnMouseClicked((new EventHandler<MouseEvent>(){ // on ferme la fenetre.
	    	  public void handle(MouseEvent event) {
	    		  stage.close();
	    	  }
	      }));
	      
	      jouer.setOnMouseClicked((new EventHandler<MouseEvent>(){ // on ferme la fenetre.
	    	  public void handle(MouseEvent event) {
	    		  MenuJeux j = new MenuJeux();
	    		  try {
					j.start(stage);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	    	  }
	      }));
	      
	     Group root = new Group(); 
	      ObservableList<Node> list = root.getChildren(); 
	      list.add(quitter);
	      list.add(text1);
	      list.add(jouer);
		
	    //creation de la scene
        Scene scene = new Scene(root,800,600);
        scene.setFill(Color.LAVENDER);  

        stage.setScene(scene);
        stage.setTitle("Menu Principal");
        stage.setResizable(true);
       
        stage.show();
    }
}
