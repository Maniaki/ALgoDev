package AlgoDev.Menu;

import AlgoDev.sudoku.MainSudoku;
import AlgoDev.sudokuLettre.MainSudokuLettre;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class MenuJeux extends Application{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}
	
	@Override
    public void start(Stage stage) throws Exception {
		
		Text text1 = new Text();
		text1.setFont(new Font(45));
		text1.setX(255);
		text1.setY(40);
		text1.setFill(Color.YELLOW);
		text1.setStrokeWidth(1);
		text1.setStroke(Color.BLUE);
		text1.setText("MENU DES JEUX");
		
		Button mots= new Button("Mots Crois�s"); 
	      mots.setLayoutX(200); 
	      mots.setLayoutY(200); 
	      mots.setScaleX(3);
	      mots.setScaleY(3);
		
		Button pendu= new Button("Pendu"); 
	      pendu.setLayoutX(500); 
	      pendu.setLayoutY(200); 
	      pendu.setScaleX(5);
	      pendu.setScaleY(3);
		
		Button motus= new Button("Motus"); 
	      motus.setLayoutX(200); 
	      motus.setLayoutY(325); 
	      motus.setScaleX(5);
	      motus.setScaleY(3);
		
		Button sudo= new Button("Sudoku"); 
	      sudo.setLayoutX(500); 
	      sudo.setLayoutY(325); 
	      sudo.setScaleX(5);
	      sudo.setScaleY(3);
		
		Button sudoLettre= new Button("Sudoku Lettre"); 
	      sudoLettre.setLayoutX(200); 
	      sudoLettre.setLayoutY(450); 
	      sudoLettre.setScaleX(3);
	      sudoLettre.setScaleY(3);
		
		
		
		Button quitter= new Button("Retour"); 
	      quitter.setLayoutX(500); 
	      quitter.setLayoutY(450); 
	      quitter.setScaleX(5);
	      quitter.setScaleY(3);
	 
	      
	      quitter.setOnMouseClicked((new EventHandler<MouseEvent>(){ // on ferme la fenetre.
	    	  public void handle(MouseEvent event) {
	    		  MenuFx m = new MenuFx();
	    		  try {
					m.start(stage);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	    	  }
	      }));
	      
	      sudo.setOnMouseClicked((new EventHandler<MouseEvent>(){ // on ferme la fenetre.
	    	  public void handle(MouseEvent event) {
	    		  MainSudoku j = new MainSudoku();
	    		  try {
					j.start(stage);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	    	  }
	      }));
	      
	      sudoLettre.setOnMouseClicked((new EventHandler<MouseEvent>(){ // on ferme la fenetre.
	    	  public void handle(MouseEvent event) {
	    		  MainSudokuLettre j = new MainSudokuLettre();
	    		  try {
					j.start(stage);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	    	  }
	      }));

		
		Group root = new Group(); 
	      ObservableList<Node> list = root.getChildren(); 
	      list.add(text1);
	      list.add(quitter);
	      list.add(sudoLettre);
	      list.add(sudo);
	      list.add(motus);
	      list.add(pendu);
	      list.add(mots);
	      
		
	    //creation de la scene
      Scene scene = new Scene(root,800,600);
      scene.setFill(Color.LAVENDER);  

      stage.setScene(scene);
      stage.setTitle("Menu Des Jeux");
      stage.setResizable(true);
     
      stage.show();
  }

}
