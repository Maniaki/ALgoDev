package AlgoDev.sudoku;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Main extends Application{

	static GrilleSudoku creerGrille(String nomFichier)
	{
		ObjectInputStream inObjectStream = null;
		GrilleSudoku grille = new GrilleSudoku(9,9);
		try {
			FileInputStream inFileStream;
			File inFile = new File(nomFichier);
			inFileStream = new FileInputStream(inFile);
			inObjectStream = new ObjectInputStream(inFileStream);
			grille = (GrilleSudoku) inObjectStream.readObject();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				inObjectStream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return grille;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	@Override
	public void start(Stage stage) throws Exception {
		Text text2 = new Text();

		//creation d'une grille
		String nomFichier = "Grille1.fic";
		final GrilleSudoku grille = creerGrille(nomFichier);
		GridPane grid = new GridPane();

		grid.setGridLinesVisible(true);
		for (int i = 0; i < 9; i++) {
			for (int j = 0; j < 9; j++) {
				TextField name = new TextField();
				name.setMaxSize(40, 40);
				if(grille.getMatrice()[i][j] == '0')
				{
					name.setText("");
				}
				else
				{
					name.setText(String.valueOf(grille.getMatrice()[i][j]));
					name.setEditable(grille.getMatCoup()[i][j]);
				}
				grid.add(name,i,j);
			}
		}
		
		grid.setScaleX(1); // limite la taille de la grille
		grid.setScaleY(1);
		grid.setScaleZ(1);     

		grid.resizeRelocate(200,150 , 400, 400);

		//Titre

		Text text1 = new Text();
		//Taille du texte
		text1.setFont(new Font(45));

		//zone ou le texte est afficher
		text1.setX(235);
		text1.setY(40);

		//couleur texte
		text1.setFill(Color.YELLOW);

		//ajouter bordure et couleur bordure texte

		text1.setStrokeWidth(2);
		text1.setStroke(Color.BLUE);

		//contenu du texte
		text1.setText("LE SUDOKU LETTRE");

		//cree un bouton
		Button sauvegarder= new Button("Sauvegarder");
		sauvegarder.setLayoutX(150);
		sauvegarder.setLayoutY(550);

		Button verifier= new Button("V�rification");
		verifier.setLayoutX(400);
		verifier.setLayoutY(550);

		Button quitter= new Button("Quitter");
		quitter.setLayoutX(650);
		quitter.setLayoutY(550);

		Button newParty= new Button("Reset");
		newParty.setLayoutX(650);
		newParty.setLayoutY(150);

		Button charger= new Button("Charger");
		charger.setLayoutX(650);
		charger.setLayoutY(250);

		//evenement pour cr�e des action pr�d�finie pour chaque bouton
		sauvegarder.setOnMouseClicked((new EventHandler<MouseEvent>() {
			public void handle(MouseEvent event)
			{
				GrilleSudoku grilleSave = grille;
				int j=0;
				int i=0;
				for( Node node: grid.getChildren()) {

					if(( node instanceof TextField)&&(((TextField) node).getText()).isEmpty()==false) { //empeche d'acceder aux nodes vides et � d'autres objets diff�rent du type node

						grilleSave.getMatrice()[i][j]=((TextField) node).getText().charAt(0);//cast les String en char
						//System.out.println(grille.matrice[i][j]);
						j=(j+1)%9;  // on recup�re les �l�ments du haut vers le bas.
						if(j==0)
						{
							i=(i+1)%9; //passe a la colonne suivante
						}
					}
				}
				try {File outFile = new File("SudokuSave.fic");
				/*if(outFile.exists())
				{
					outFile.delete(); //supprime le contennu du fichier avant de pouvoir sauvegarder a nouveau dessus si il existe.
				}*/

				FileOutputStream outFileStream = new FileOutputStream(outFile);
				ObjectOutputStream outObjectStream = new ObjectOutputStream(outFileStream);
				outObjectStream.writeObject(grilleSave);
				outObjectStream.close();
				} catch (Exception e) {
					e.printStackTrace();
				}

				text2.setFont(new Font(25));
				text2.setX(300);
				text2.setY(500);
				text2.setText("Sauvegard�");

			}
		}));

		verifier.setOnMouseClicked((new EventHandler<MouseEvent>(){
			public void handle(MouseEvent event) {
				int j=0;
				int i=0;
				for( Node node: grid.getChildren()) {

					if(( node instanceof TextField)&&(((TextField) node).getText()).isEmpty()==false) {

						grille.getMatrice()[i][j]=((TextField) node).getText().charAt(0);
						System.out.println(grille.getMatrice()[i][j]);
						j=(j+1)%9;
						if(j==0)
						{
							i=(i+1)%9;

						}
					}
				}

				//ici, on recupere les �l�ments , on les stocks dans la grille a leur emplacement et on v�rifie si il y a des doublons par ligne, colonne et region.              
				if(grille.verifie_unicite()==true)
				{
					text2.setFont(new Font(25));
					text2.setX(300);
					text2.setY(500);
					text2.setText("Vous avez Gagn�");
					//victoire
				}
				else
				{
					text2.setFont(new Font(25));
					text2.setX(255);
					text2.setY(500);
					text2.setText("Vous n'avez pas la bonne solution");
					//perdu
				}

			}
		}));

		quitter.setOnMouseClicked((new EventHandler<MouseEvent>(){ // on ferme la fenetre.
			public void handle(MouseEvent event) {
				System.out.println("Au revoir");
				stage.close();
			}
		}));

		newParty.setOnMouseClicked((new EventHandler<MouseEvent>(){  //reset
              public void handle(MouseEvent event) {
            	  
            	  try {
  					GrilleSudoku grille = creerGrille(nomFichier);
            		for(int k = 0;k<9;k++)
  					{
  						for(int l = 0; l<9;l++)
  						{
  							TextField name = new TextField();
  							name.setMaxSize(40, 40);
  							if(grille.getMatrice()[k][l]=='0')
  								name.setText(" ");
  							else
  							{
  								name.setText(String.valueOf(grille.getMatrice()[k][l]));
  								name.setEditable(grille.getMatCoup()[k][l]);
  							}
  							grid.add(name,k,l);
  						}
  					}
  					text2.setFont(new Font(25));
  					text2.setX(300);
  					text2.setY(500);
  					text2.setText("Partie Reset");

  				}catch ( Exception e1) {
  					// TODO Auto-generated catch block
  					e1.printStackTrace();
  				}
              }
          }));

		charger.setOnMouseClicked((new EventHandler<MouseEvent>(){ // charger partie
			public void handle(MouseEvent event) {

				// Charger partie sauvegarder
				try {
					GrilleSudoku grille = creerGrille("SudokuSave.fic");
					for(int k = 0;k<9;k++)
					{
						for(int l = 0; l<9;l++)
						{
							TextField name = new TextField();
							name.setMaxSize(40, 40);
							if(grille.getMatrice()[k][l]=='0')
								name.setText("");
							else
							{
								name.setText(String.valueOf(grille.getMatrice()[k][l]));
								name.setEditable(grille.getMatCoup()[k][l]);
							}
							grid.add(name,k,l);
						}
					}
					text2.setFont(new Font(25));
					text2.setX(300);
					text2.setY(500);
					text2.setText("Vous avez charg� la partie");

				}catch ( Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}



			}}));

		Group root = new Group();

		//Retrieving the observable list object
		//liste qu contient les btn et les textes
		ObservableList<Node> list = root.getChildren();

		//Setting the text object as a node to the group object
		list.add(text1);
		list.add(sauvegarder);
		list.add(verifier);
		list.add(quitter);
		list.add(newParty);
		list.add(charger);
		list.add(text2);

		list.add(grid);

		//creation de la scene
		Scene scene = new Scene(root,800,600);
		scene.setFill(Color.LAVENDER);  

		stage.setScene(scene);
		stage.setTitle("Le Sudoku Lettre");
		stage.setResizable(false);

		stage.show();
	}

}