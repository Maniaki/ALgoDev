package AlgoDev.sudoku;

/*
 * Permet de creer des fichier grille
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class TestSudoku {

	static void ecritureFichier()
	{
		File outFile = new File("Grille1.fic");
		try {
			char[][] m = new char[9][9];
			for(int i = 0; i < 9; i++)
			{
				for(int j = 0; j < 9; j++)
				{
					m[i][j] = '0';
				}
			}
			m[0][1] = '6';
			m[0][2] = '9';
			m[0][5] = '5';
			m[0][6] = '1';
			m[0][8] = '2';
			m[1][0] = '7';
			m[1][3] = '2';
			m[1][4] = '6';
			m[1][8] = '9';
			m[2][4] = '7';
			m[2][6] = '8';
			m[2][7] = '5';
			m[3][0] = '3';
			m[3][1] = '7';
			m[3][7] = '8';
			m[4][1] = '9';
			m[4][3] = '8';
			m[4][5] = '7';
			m[4][7] = '1';
			m[5][1] = '2';
			m[5][7] = '4';
			m[5][8] = '7';
			m[6][1] = '3';
			m[6][2] = '2';
			m[6][4] = '8';
			m[7][0] = '5';
			m[7][4] = '1';
			m[7][5] = '2';
			m[7][8] = '4';
			m[8][0] = '4';
			m[8][2] = '6';
			m[8][3] = '3';
			m[8][6] = '7';
			m[8][7] = '2';
			GrilleSudoku g = new GrilleSudoku(m);
			FileOutputStream outFileStream = new FileOutputStream(outFile);
			ObjectOutputStream outObjectStream = new ObjectOutputStream(outFileStream);
			outObjectStream.writeObject(g);
			outObjectStream.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	static void creerGrilleResolue()
	{
		File outFile = new File("Grille1Resolue.fic");
		try {
			char[][] m = new char[9][9];
			for(int i = 0; i < 9; i++)
			{
				for(int j = 0; j < 9; j++)
				{
					m[i][j] = '0';
				}
			}
			m[0][0] = '8';
			m[0][1] = '6';
			m[0][2] = '9';
			m[0][3] = '4';
			m[0][4] = '3';
			m[0][5] = '5';
			m[0][6] = '1';
			m[0][7] = '7';
			m[0][8] = '2';
			m[1][0] = '7';
			m[1][1] = '5';
			m[1][2] = '1';
			m[1][3] = '2';
			m[1][4] = '6';
			m[1][5] = '8';
			m[1][6] = '4';
			m[1][7] = '3';
			m[1][8] = '9';
			m[2][0] = '2';
			m[2][1] = '4';
			m[2][2] = '3';
			m[2][3] = '9';
			m[2][4] = '7';
			m[2][5] = '1';
			m[2][6] = '8';
			m[2][7] = '5';
			m[2][8] = '6';
			m[3][0] = '3';
			m[3][1] = '7';
			m[3][2] = '4';
			m[3][3] = '1';
			m[3][4] = '2';
			m[3][5] = '6';
			m[3][6] = '9';
			m[3][7] = '8';
			m[3][8] = '5';
			m[4][0] = '6';
			m[4][1] = '9';
			m[4][2] = '5';
			m[4][3] = '8';
			m[4][4] = '4';
			m[4][5] = '7';
			m[4][6] = '2';
			m[4][7] = '1';
			m[4][8] = '3';
			m[5][0] = '1';
			m[5][1] = '2';
			m[5][2] = '8';
			m[5][3] = '5';
			m[5][4] = '9';
			m[5][5] = '3';
			m[5][6] = '6';
			m[5][7] = '4';
			m[5][8] = '7';
			m[6][0] = '9';
			m[6][1] = '3';
			m[6][2] = '2';
			m[6][3] = '7';
			m[6][4] = '8';
			m[6][5] = '4';
			m[6][6] = '5';
			m[6][7] = '6';
			m[6][8] = '1';
			m[7][0] = '5';
			m[7][1] = '8';
			m[7][2] = '7';
			m[7][3] = '6';
			m[7][4] = '1';
			m[7][5] = '2';
			m[7][6] = '3';
			m[7][7] = '9';
			m[7][8] = '4';
			m[8][0] = '4';
			m[8][1] = '1';
			m[8][2] = '6';
			m[8][3] = '3';
			m[8][4] = '5';
			m[8][5] = '9';
			m[8][6] = '7';
			m[8][7] = '2';
			m[8][8] = '8';
			GrilleSudoku g = new GrilleSudoku(m);
			FileOutputStream outFileStream = new FileOutputStream(outFile);
			ObjectOutputStream outObjectStream = new ObjectOutputStream(outFileStream);
			outObjectStream.writeObject(g);
			outObjectStream.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ecritureFichier();
		creerGrilleResolue();
	}

}
