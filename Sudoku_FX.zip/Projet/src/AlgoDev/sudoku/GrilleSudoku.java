package AlgoDev.sudoku;

import java.io.Serializable;

public class GrilleSudoku extends Grille implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private boolean[][] matCoup = new boolean[9][9];
	
	public GrilleSudoku(int nbColonne, int nbLigne) {
		super(nbColonne, nbLigne);
		// TODO Auto-generated constructor stub
		this.initializeMatCoup();
	}
	
	public GrilleSudoku(char matrice[][])
	{
		super(9,9, matrice);
		this.initializeMatCoup();
	}
	
	public boolean[][] getMatCoup() {
		return matCoup;
	}

	public void setMatCoup(boolean[][] matCoup) {
		this.matCoup = matCoup;
	}

	public void initializeMatCoup()
	{
		if(this.getMatrice() != null)
		{
		int i;
		int j;
		for(i=0;i < this.getNbLigne();i++)
		{
			for(j=0;j < this.getNbColonne();j++)
			{
				if(this.getMatrice()[i][j] == '0')
					matCoup[i][j]=true;
				else
					matCoup[i][j]=false;
			}
		}
		}
	}
	
	public boolean unicite_ligne() // verifie s'il n'y a pas de doublons en ligne
	{
		boolean[] tab = new boolean[9];


		for(int i = 0;i<=8;i++)
		{
			for(int j = 0; j<=8;j++)
			{
				tab[j]=false;
			}
			for ( int k = 0; k<=8;k++)
			{
				switch(this.getMatrice()[i][k])
				{
				case '1':
				{
					if (tab[0]== true)
					{
						return false;
					}
					else
					{
						tab[0]= true;
					}
					break;
				}
				case '2':
				{
					if (tab[1]== true)
					{
						return false;
					}
					else
					{
						tab[1]= true;
					}
					break;
				}
				case '3':
				{
					if (tab[2]== true)
					{
						return false;
					}
					else
					{
						tab[2]= true;
					}
					break;
				}
				case '4':
				{
					if (tab[3]== true)
					{
						return false;
					}
					else
					{
						tab[3]= true;
					}
					break;
				}
				case '5':
				{
					if (tab[4]== true)
					{
						return false;
					}
					else
					{
						tab[4]= true;
					}
					break;
				}
				case '6':
				{
					if (tab[5]== true)
					{
						return false;
					}
					else
					{
						tab[5]= true;
					}
					break;
				}
				case '7':
				{
					if (tab[6]== true)
					{
						return false;
					}
					else
					{
						tab[6]= true;
					}
					break;
				}
				case '8':
				{
					if (tab[7]== true)
					{
						return false;
					}
					else
					{
						tab[7]= true;
					}
					break;
				}
				case '9':
				{
					if (tab[8]== true)
					{
						return false;
					}
					else
					{
						tab[8]= true;
					}
					break;
				}
				default :
				{
					return false;
				}
				}
			}
		}
		return true;
	}

	public boolean unicite_colonne() // Verifie si pas de doublons en colonne
	{
		boolean[] tab = new boolean[9];

		int i,j,k;

		for( i = 0;i<=8;i++)
		{
			for( j = 0; j<=8;j++)
			{
				tab[j]=false;
			}
			for ( k = 0; k<=8;k++)
			{
				switch(this.getMatrice()[k][i])
				{
				case '1':
				{
					if (tab[0]== true)
					{
						return false;
					}
					else
					{
						tab[0]= true;
					}
					break;
				}
				case '2':
				{
					if (tab[1]== true)
					{
						return false;
					}
					else
					{
						tab[1]= true;
					}
					break;
				}
				case '3':
				{
					if (tab[2]== true)
					{
						return false;
					}
					else
					{
						tab[2]= true;
					}
					break;
				}
				case '4':
				{
					if (tab[3]== true)
					{
						return false;
					}
					else
					{
						tab[3]= true;
					}
					break;
				}
				case '5':
				{
					if (tab[4]== true)
					{
						return false;
					}
					else
					{
						tab[4]= true;
					}
					break;
				}
				case '6':
				{
					if (tab[5]== true)
					{
						return false;
					}
					else
					{
						tab[5]= true;
					}
					break;
				}
				case '7':
				{
					if (tab[6]== true)
					{
						return false;
					}
					else
					{
						tab[6]= true;
					}
					break;
				}
				case '8':
				{
					if (tab[7]== true)
					{
						return false;
					}
					else
					{
						tab[7]= true;
					}
					break;
				}
				case '9':
				{
					if (tab[8]== true)
					{
						return false;
					}
					else
					{
						tab[8]= true;
					}
					break;
				}
				default :
				{
					return false;
				}
				}
			}
		}
		return true;
	}

	public boolean unicite_Region(int l, int c)
	{
		boolean tab2[] = new boolean[9];
		for(int t = 0; t<=8;t++)
		{
			tab2[t]=false;
		}
		for (int i = l;i<=l+2;i++)
		{
			for(int j= c;j<=c+2;j++)
			{
				switch(this.getMatrice()[i][j])
				{
				case '1':
				{
					if (tab2[0]== true)
					{
						return false;
					}
					else
					{
						tab2[0]= true;
					}
					break;
				}
				case '2':
				{
					if (tab2[1]== true)
					{
						return false;
					}
					else
					{
						tab2[1]= true;
					}
					break;
				}
				case '3':
				{
					if (tab2[2]== true)
					{
						return false;
					}
					else
					{
						tab2[2]= true;
					}
					break;
				}
				case '4':
				{
					if (tab2[3]== true)
					{
						return false;
					}
					else
					{
						tab2[3]= true;
					}
					break;
				}
				case '5':
				{
					if (tab2[4]== true)
					{
						return false;
					}
					else
					{
						tab2[4]= true;
					}
					break;
				}
				case '6':
				{
					if (tab2[5]== true)
					{
						return false;
					}
					else
					{
						tab2[5]= true;
					}
					break;
				}
				case '7':
				{
					if (tab2[6]== true)
					{
						return false;
					}
					else
					{
						tab2[6]= true;
					}
					break;
				}
				case '8':
				{
					if (tab2[7]== true)
					{
						return false;
					}
					else
					{
						tab2[7]= true;
					}
					break;
				}
				case '9':
				{
					if (tab2[8]== true)
					{
						return false;
					}
					else
					{
						tab2[8]= true;
					}
					break;
				}
				default :
				{
					return false;
				}
				}
			}
		}
		return true;
	}

	public boolean verifie_unicite()
	{
		if(unicite_ligne() == false)
		{
			return false;
		}
		if(unicite_colonne() == false)
		{
			return false;
		}
		for(int i = 0;i<9;i=i+3)
		{
			for(int j=0;j<9;j=j+3)
			{
				if(unicite_Region(i,j)==false)
				{
					return false;
				}
			}
		}
		return true;

	}

}
