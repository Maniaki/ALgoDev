package testJavafx;

import java.io.Serializable;

public class Grille_Sudoku implements Serializable{

	protected int nbColonne = 9;
	protected int nbLigne = 9;
	protected char[][] matrice = new char[9][9];
	protected boolean[][] mat2 = new boolean[9][9];
	
	public Grille_Sudoku() {
		
	}
	
	public int getNbColonne() {
		return nbColonne;
	}
	
	public void setNbColonne(int nbColonne) {
		this.nbColonne = nbColonne;
	}
	
	public int getNbLigne() {
		return nbLigne;
	}
	
	public void setNbLigne(int nbLigne) {
		this.nbLigne = nbLigne;
	}
	
	public char[][] getMatrice() {
		return matrice;
	}
	
	public void setMatrice(char[][] matrice) {
		this.matrice = matrice;
	}
	
	public void initializeGrid()
	{
		int i = 0;
		int j =0;
		for(i=0;i<=8;i++)
		{
			for(j=0;j<=8;j++)
			{
				matrice[i][j]='o';
				mat2[i][j]=false;
			}
		}
	}
	
	public void charger_grille(Grille_Sudoku g)
	{
		this.matrice=g.matrice;
		this.mat2=g.mat2;
		
	}
	
	public void nouvelle_grille()
	{
		matrice[0][0]='A';
		matrice[0][3]='H';
		matrice[0][4]='C';
		matrice[0][8]='B';
		matrice[1][0]='E';
		matrice[1][1]='G';
		matrice[1][5]='A';
		matrice[2][3] = 'E';
		matrice[2][5] = 'I';
		matrice[2][7] = 'F';
		matrice[2][8] = 'D';
		matrice[3][0] = 'G';
		matrice[3][2] = 'D';
		matrice[3][5] = 'H';
		matrice[3][6] = 'E';
		matrice[3][7] = 'I';
		matrice[4][2] = 'C';
		matrice[4][4] = 'A';
		matrice[4][6] = 'D';
		matrice[5][1] = 'E';
		matrice[5][2] = 'A';
		matrice[5][3] = 'D';
		matrice[5][6] = 'C';
		matrice[5][8] = 'F';
		matrice[6][0] = 'C';
		matrice[6][1] = 'F';
		matrice[6][3] = 'G';
		matrice[6][5] = 'D';
		matrice[7][3] = 'F';
		matrice[7][7] = 'G';
		matrice[7][8] = 'I';
		matrice[8][0] = 'H';
		matrice[8][4] = 'E';
		matrice[8][5] = 'B';
		matrice[8][8] = 'C';
		mat2();
	}
	
	public void mat2()
	{
		for(int i = 0;i<9;i++)
		{
			for(int j =0; j<9;j++)
			{
				if(matrice[i][j]!='o')
				{
					mat2[i][j]= true;
				}
			}
		}
	}
	
	public boolean unicite_ligne()
	{
		boolean[] tab = new boolean[9];
		
		
		for(int i = 0;i<=8;i++)
		{
			for(int j = 0; j<=8;j++)
		{
			tab[j]=false;
		}
			for ( int k = 0; k<=8;k++)
			{
				switch(matrice[i][k])
				{
				case 'A':
				{
					if (tab[0]== true)
					{
						return false;
					}
					else
					{
						tab[0]= true;
					}
					break;
				}
				case 'B':
				{
					if (tab[1]== true)
					{
						return false;
					}
					else
					{
						tab[1]= true;
					}
					break;
				}
				case 'C':
				{
					if (tab[2]== true)
					{
						return false;
					}
					else
					{
						tab[2]= true;
					}
					break;
				}
				case 'D':
				{
					if (tab[3]== true)
					{
						return false;
					}
					else
					{
						tab[3]= true;
					}
					break;
				}
				case 'E':
				{
					if (tab[4]== true)
					{
						return false;
					}
					else
					{
						tab[4]= true;
					}
					break;
				}
				case 'F':
				{
					if (tab[5]== true)
					{
						return false;
					}
					else
					{
						tab[5]= true;
					}
					break;
				}
				case 'G':
				{
					if (tab[6]== true)
					{
						return false;
					}
					else
					{
						tab[6]= true;
					}
					break;
				}
				case 'H':
				{
					if (tab[7]== true)
					{
						return false;
					}
					else
					{
						tab[7]= true;
					}
					break;
				}
				case 'I':
				{
					if (tab[8]== true)
					{
						return false;
					}
					else
					{
						tab[8]= true;
					}
					break;
				}
				default:
				{
					break;
				}
				}
			}
		}
		return true;
	}
	
	public boolean unicite_colonne()
	{
		boolean[] tab = new boolean[9];
		
		
		for(int i = 0;i<=8;i++)
		{
			for(int j = 0; j<=8;j++)
		{
			tab[j]=false;
		}
			for ( int k = 0; k<=8;k++)
			{
				switch(matrice[k][i])
				{
				case 'A':
				{
					if (tab[0]== true)
					{
						return false;
					}
					else
					{
						tab[0]= true;
					}
					break;
				}
				case 'B':
				{
					if (tab[1]== true)
					{
						return false;
					}
					else
					{
						tab[1]= true;
					}
					break;
				}
				case 'C':
				{
					if (tab[2]== true)
					{
						return false;
					}
					else
					{
						tab[2]= true;
					}
					break;
				}
				case 'D':
				{
					if (tab[3]== true)
					{
						return false;
					}
					else
					{
						tab[3]= true;
					}
					break;
				}
				case 'E':
				{
					if (tab[4]== true)
					{
						return false;
					}
					else
					{
						tab[4]= true;
					}
					break;
				}
				case 'F':
				{
					if (tab[5]== true)
					{
						return false;
					}
					else
					{
						tab[5]= true;
					}
					break;
				}
				case 'G':
				{
					if (tab[6]== true)
					{
						return false;
					}
					else
					{
						tab[6]= true;
					}
					break;
				}
				case 'H':
				{
					if (tab[7]== true)
					{
						return false;
					}
					else
					{
						tab[7]= true;
					}
					break;
				}
				case 'I':
				{
					if (tab[8]== true)
					{
						return false;
					}
					else
					{
						tab[8]= true;
					}
					break;
				}
				default :
				{
					break;
				}
				}
			}
		}
		return true;
	}
	
	
	boolean unicite_Region(int l, int c)
{
 boolean tab2[] = new boolean[9];
 for(int t = 0; t<=8;t++)
 {
	 tab2[t]=false;
 }
 for (int i = l;i<=l+2;i++)
 {
	 for(int j= c;j<=c+2;j++)
	 {
		 switch(matrice[i][j])
			{
			case 'A':
			{
				if (tab2[0]== true)
				{
					return false;
				}
				else
				{
					tab2[0]= true;
				}
				break;
			}
			case 'B':
			{
				if (tab2[1]== true)
				{
					return false;
				}
				else
				{
					tab2[1]= true;
				}
				break;
			}
			case 'C':
			{
				if (tab2[2]== true)
				{
					return false;
				}
				else
				{
					tab2[2]= true;
				}
				break;
			}
			case 'D':
			{
				if (tab2[3]== true)
				{
					return false;
				}
				else
				{
					tab2[3]= true;
				}
				break;
			}
			case 'E':
			{
				if (tab2[4]== true)
				{
					return false;
				}
				else
				{
					tab2[4]= true;
				}
				break;
			}
			case 'F':
			{
				if (tab2[5]== true)
				{
					return false;
				}
				else
				{
					tab2[5]= true;
				}
				break;
			}
			case 'G':
			{
				if (tab2[6]== true)
				{
					return false;
				}
				else
				{
					tab2[6]= true;
				}
				break;
			}
			case 'H':
			{
				if (tab2[7]== true)
				{
					return false;
				}
				else
				{
					tab2[7]= true;
				}
				break;
			}
			case 'I':
			{
				if (tab2[8]== true)
				{
					return false;
				}
				else
				{
					tab2[8]= true;
				}
				break;
			}
			default :
			{
				break;
			}
			}
		}
	 }
return true;
}
	
	public boolean verifie_unicite()
	{
		for(int i =0;i<9;i++)
		{
			for(int j =0;j<9;j++)
			{
				if((matrice[i][j]!='A')&&(matrice[i][j]!='B')&&(matrice[i][j]!='C')&&(matrice[i][j]!='D')&&
						(matrice[i][j]!='E')&&(matrice[i][j]!='F')&&(matrice[i][j]!='G')&&(matrice[i][j]!='H')&&(matrice[i][j]!='I')) {
					return false;
				}
			}
		}
		if(unicite_ligne() == false)
		{
			return false;
		}
		if(unicite_colonne() == false)
		{
			return false;
		}
		for(int i = 0;i<9;i=i+3)
		{
			for(int j=0;j<9;j=j+3)
			{
				if(unicite_Region(i,j)==false)
				{
					return false;
				}
			}
		}
		return true;
		
	}
	

	
	public void jouer_un_coup(int i, int j, char c)
	{
		matrice[i-1][j-1]=c;
	}
	
	public void afficher_grille()
	{
		for( int i = 0;i<=8;i++)
		{
			System.out.println( matrice[i][0] + " | " + matrice[i][1] + " | " + matrice[i][2] + " | " +matrice[i][3] + " | " +
					matrice[i][4] + " | " + matrice[i][5] + " | " + matrice[i][6] + " | " + matrice[i][7] + " | " + matrice[i][8] + " | " );
		}
	}

	/*public boolean est_fini()
	{
		for(int i=0;i<9;i++)
		{
			for(int j =0;j<9;j++)
			{
				if((matrice[i][j]!='A')||(matrice[i][j]!='B')||(matrice[i][j]!='C')||(matrice[i][j]!='D')||(matrice[i][j]!='E')||(matrice[i][j]!='F')||(matrice[i][j]!='G')||(matrice[i][j]!='H')||(matrice[i][j]!='I'))
				{
					System.out.println(matrice[i][j]);
					return false;
				}
			}
		}
		return true;
	}*/
	
	
}
