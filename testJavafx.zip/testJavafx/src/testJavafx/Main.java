package testJavafx;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Main extends Application{


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}
	
	@Override
    public void start(Stage stage) throws Exception {
		
		
		Text text2 = new Text();
		Text text3 = new Text();
		Text text4 = new Text();
		
		text3.setFont(new Font(10));
		text3.setX(650);
		text3.setY(350);
		text3.setText("Score :");
		
		text4.setFont(new Font(10));
		text4.setX(650);
		text4.setY(400);
		text4.setText("Temps :");
		
		
		//creation d'une grille
		
		Grille_Sudoku grille = new Grille_Sudoku();
		grille.initializeGrid();
		grille.nouvelle_grille();
		
		
		GridPane grid = new GridPane();
		
		grid.setGridLinesVisible(true); // pour afficher la grille
		for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
            	TextField name = new TextField();
            	name.setMaxSize(40, 40);
            	if(grille.matrice[i][j]=='o')// on remplace les char a modifie par un char " "
				  {
				  
				  name.setText(" ");
				  }else
				  {name.setText(String.valueOf(grille.matrice[i][j]));}
				 
					name.setEditable(!grille.mat2[i][j]);  // pour empecher la modification des �l�ment fixe du jeu
                  grid.add(name,i,j);
}
}
		
	    grid.setScaleX(1); // limite la taille de la grille
	    grid.setScaleY(1);
	    grid.setScaleZ(1);	    
		
		grid.resizeRelocate(200,150 , 400, 400);
	
		//Titre
		
		Text text1 = new Text();
		//Taille du texte 
		text1.setFont(new Font(45));
		
		//zone ou le texte est afficher
		text1.setX(235);
		text1.setY(40);
		
		//couleur texte
		text1.setFill(Color.YELLOW);
		
		//ajouter bordure et couleur bordure texte
		
		text1.setStrokeWidth(1);
		text1.setStroke(Color.BLUE);
		
		//contenu du texte
		text1.setText("LE SUDOKU LETTRE");
		
	
		//cree un bouton 
	      Button sauvegarder= new Button("Sauvegarder"); 
	      sauvegarder.setLayoutX(150); 
	      sauvegarder.setLayoutY(550); 
	      
	      Button verifier= new Button("V�rification"); 
	      verifier.setLayoutX(400); 
	      verifier.setLayoutY(550); 
	      
	      Button quitter= new Button("Quitter"); 
	      quitter.setLayoutX(650); 
	      quitter.setLayoutY(550); 
	      
	      Button reset= new Button("Reset"); 
	      reset.setLayoutX(650); 
	      reset.setLayoutY(150); 
	      
	      Button charger= new Button("Charger"); 
	      charger.setLayoutX(650); 
	      charger.setLayoutY(250); 
	      
	      //evenement pour cr�e des action pr�d�finie pour chaque bouton
	      sauvegarder.setOnMouseClicked((new EventHandler<MouseEvent>() {
	    	  public void handle(MouseEvent event)
	    	  {
	    		  
	    		 int j=0;
	    		  int i=0;
	    		  for( Node node: grid.getChildren()) {

	                    if(( node instanceof TextField)&&(((TextField) node).getText()).isEmpty()==false) { //empeche d'acceder aux nodes vides et � d'autres objets diff�rent du type node
	                    	
	                       grille.matrice[i][j]=((TextField) node).getText().charAt(0);//cast les String en char
	                       j=(j+1)%9;  // on recup�re les �l�ments du haut vers le bas.
	                       if(j==0)
	                       {
	                    	   i=(i+1)%9; //passe a la colonne suivante
	                    	   
	                       } 
	                    
	                }
	    		  }
				try {File outFile = new File("SudokuSave.fic"); 
				if(outFile.exists())
				{
					outFile.delete(); //supprime le contennu du fichier avant de pouvoir sauvegarder a nouveau dessus si il existe.
				}
				
					FileOutputStream outFileStream = new FileOutputStream(outFile);
					ObjectOutputStream outObjectStream = new ObjectOutputStream(outFileStream);
					outObjectStream.writeObject(grille);
					outObjectStream.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				 text2.setFont(new Font(25));
   			  text2.setX(300);
   			  text2.setY(500);
				  text2.setText("Sauvegard�");
				
	    	  }
	      }));
	      
	      verifier.setOnMouseClicked((new EventHandler<MouseEvent>(){
	    	  public void handle(MouseEvent event) {
	    		  int j=0;
	    		  int i=0;
	    		  for( Node node: grid.getChildren()) {

	                    if(( node instanceof TextField)&&(((TextField) node).getText()).isEmpty()==false) {
	                    	
	                       grille.matrice[i][j]=((TextField) node).getText().charAt(0); 
	                       j=(j+1)%9;
	                       if(j==0)
	                       {
	                    	   i=(i+1)%9;
	                    	   
	                       } 
	                }
	    		  }
	    		
	//ici, on recupere les �l�ments , on les stocks dans la grille a leur emplacement et on v�rifie si il y a des doublons par ligne, colonne et region.    			  
	    			  if(grille.verifie_unicite()==true)
	    			  {
	    				  text2.setFont(new Font(25));
		    			  text2.setX(300);
		    			  text2.setY(500);
	    				  text2.setText("Vous avez Gagn�");
	    				  //victoire
	    			  }
	    			  else
	    			  {
	    				  text2.setFont(new Font(25));
		    			  text2.setX(255);
		    			  text2.setY(500);
	    				  text2.setText("Vous n'avez pas la bonne solution");
	    				  //perdu
	    			  }
	    		  
	    	  }
	      }));
	      
	      quitter.setOnMouseClicked((new EventHandler<MouseEvent>(){ // on ferme la fenetre.
	    	  public void handle(MouseEvent event) {
	    		  System.out.println("Au revoir");
	    		  stage.close();
	    	  }
	      }));
		
	     reset.setOnMouseClicked((new EventHandler<MouseEvent>(){  //reset
	    	  public void handle(MouseEvent event) {
	    		  grille.initializeGrid();
	    		  grille.nouvelle_grille();
	    		  for(int k = 0;k<9;k++)
	    		  {
	    			  for(int l = 0; l<9;l++)
	    			  {
	    				  TextField name = new TextField();
	    				  name.setMaxSize(40, 40);
	    				  if(grille.matrice[k][l]=='o')
	    				  {
	    				  
	    				  name.setText(" ");
	    				  }else
	    				  {name.setText(String.valueOf(grille.matrice[k][l]));}
	    				 
	    					name.setEditable(!grille.mat2[k][l]);
	    					 grid.add(name,k,l);
	    				  
	    				 
	    			  }
	    		  }
	    	  }
	      }));
		
	     charger.setOnMouseClicked((new EventHandler<MouseEvent>(){ // charger partie
	    	  public void handle(MouseEvent event) {

					// Charger partie sauvegarder
					try {
					FileInputStream inFileStream;
					File inFile = new File("SudokuSave.fic");
					inFileStream = new FileInputStream(inFile);
					ObjectInputStream inObjectStream = new ObjectInputStream(inFileStream);
					Grille_Sudoku grille2 = (Grille_Sudoku) inObjectStream.readObject();
					grille.charger_grille(grille2);//on cr�er une nouvelle grille , on recupere le contenu du fichier et ensuite on le transfere dans notre premiere grille.
					inObjectStream.close();
					for(int k = 0;k<9;k++)
		    		  {
		    			  for(int l = 0; l<9;l++)
		    			  {
		    				  TextField name = new TextField();
		    				  name.setMaxSize(40, 40);
		    				  
		    				  if(grille.matrice[k][l]=='o')
		    				  {
		    				  
		    				  name.setText(" ");
		    				  }else
		    				  {name.setText(String.valueOf(grille.matrice[k][l]));}
		    				 
		    					name.setEditable(!grille.mat2[k][l]);
		    					 grid.add(name,k,l);
		    					 
		    				 
		    			  }
		    		  }
					text2.setFont(new Font(25));
	    			  text2.setX(300);
	    			  text2.setY(500);
	    			  text2.setText("Vous avez charg� la partie");
					
					}catch ( Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
					
	    	    
					 
	    	  }}));
	     
		//parametre de la fenetre
		Group root = new Group();

		//liste qu contient les btn et les textes
	      ObservableList<Node> list = root.getChildren(); 
	       
	      list.add(text1); 
	      list.add(sauvegarder);
	      list.add(verifier);
	      list.add(quitter);
	      list.add(reset);
	      list.add(charger);
	      list.add(text2);
	      list.add(text3);
	      list.add(text4);
		
	     list.add(grid);
	     
	     //creation de la scene
        Scene scene = new Scene(root,800,600);
        scene.setFill(Color.LAVENDER);  

        stage.setScene(scene);
        stage.setTitle("Le Sudoku Lettre");
        stage.setResizable(false);
       
        stage.show();
    }

}
