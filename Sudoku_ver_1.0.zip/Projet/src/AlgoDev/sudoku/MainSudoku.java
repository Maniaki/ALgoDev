/*
 * Version 1.0 derni�re modification 15-10-2018
 * Creer par St�phane Cocquebert avec l'aide de William Larcy
 * 
 * Point cl�s :
 * Jouer au sudoku
 * Annuler des coups
 * Sauvegarder une grille
 * Reprendre une partie (Manuel)
 */
package AlgoDev.sudoku;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class MainSudoku {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		FileInputStream inFileStream;
		try {
			// Charger partie sauvegarder
			/*
			File inFile = new File("SudokuSave.fic");
			inFileStream = new FileInputStream(inFile);
			ObjectInputStream inObjectStream = new ObjectInputStream(inFileStream);
			Sudoku partie = (Sudoku) inObjectStream.readObject();
			inObjectStream.close();
			*/
			
			//Creer nouvelle partie

			File inFile = new File("Grille1.fic");
			inFileStream = new FileInputStream(inFile);
			inFile = new File("Grille1.fic");
			ObjectInputStream inObjectStream = new ObjectInputStream(inFileStream);
			Grille_sudoku g = (Grille_sudoku) inObjectStream.readObject();
			inObjectStream.close();
			Sudoku partie = new Sudoku(g); 	// Creation partie

			if(partie != null)
			{
				int choix = -1;
				// Debut partie
				while(choix  != 0)
				{
					partie.getGrille().affiche_grille();
					System.out.println("0) Quitter\n1) Jouer un coup\n2) Annuler un coup\n3) Valider la grille\n4) sauvegarder la grille");
					choix = sc.nextInt();
					sc.nextLine();
					switch(choix)
					{
					case 0 :
						System.out.println("au revoir merci d'avoir jouer !");
						break;
					case 1 :
						System.out.println("Saisir ligne");
						int x = sc.nextInt();
						sc.nextLine();
						System.out.println("Saisir colonne");
						int y = sc.nextInt();
						sc.nextLine();
						System.out.println("Saisir valeur a inserer");
						char symbole = sc.next().charAt(0);
						sc.nextLine();
						if(partie.saisir_coup(x,y,symbole) == false)
						{
							System.out.println("le coup n'a pas put �tre jou� ");
						}
						break;
					case 2 :
						if(partie.annuler_coup() == false)
						{
							System.out.println("Le coup n'a pas pu �tre annul�");
						}
						break;
					case 3:
						if(partie.valider_Grille() == false)
						{
							System.out.println("Grille incorrecte ou incomplete");
						}
						else
							choix = 0;
						System.out.println("Felicitation ! Vous avez gagn� !");
						break;
					case 4 :
						File outFile = new File("SudokuSave.fic");
						try {
							FileOutputStream outFileStream = new FileOutputStream(outFile);
							ObjectOutputStream outObjectStream = new ObjectOutputStream(outFileStream);
							outObjectStream.writeObject(partie);
							outObjectStream.close();
						} catch (FileNotFoundException e) {
							e.printStackTrace();
						} catch (IOException e) {
							e.printStackTrace();
						}
						choix = 0;
						System.out.println("A bientot");
						break;
					}
				}
			}
			sc.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}
