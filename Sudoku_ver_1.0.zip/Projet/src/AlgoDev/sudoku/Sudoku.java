package AlgoDev.sudoku;

import java.io.Serializable;

public class Sudoku implements Serializable{

	// Atribut

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Grille_sudoku grille;
	public Pile pile;

	// Constructeur

	public Sudoku(Grille_sudoku g)
	{
		this.grille = g;
		this.pile = new Pile();
	}

	public Sudoku(Grille_sudoku g, Pile p)
	{
		this.grille = g;
		this.pile = p;
	}
	

	// getter setter

	public Grille_sudoku getGrille() {
		return grille;
	}

	public void setGrille(Grille_sudoku grille) {
		this.grille = grille;
	}

	public Pile getPile() {
		return pile;
	}

	public void setPile(Pile pile) {
		this.pile = pile;
	}

	// Methode

	public boolean saisir_coup(int x, int y , char symbole) // retourne true si coup jou� false sinon
	{
		if(x > 0 && x < 10 && y > 0 && y < 10)
		{
			if(symbole == '1' || symbole == '2' || symbole == '3' || symbole == '4' || symbole == '5' || symbole == '6' || symbole == '7' || symbole == '8' || symbole == '9') 
			{
						return(grille.jouer_un_coup(x-1, y-1, symbole, pile));
			}
		}
		return false;
	}

	public boolean annuler_coup()
	{
		if(pile.getNiveau() >= 0)
		{
			Coup c = pile.getPile().get(pile.getNiveau());
			if(pile.depile() == true)
			{
				grille.suprimmer_coup(c.getX(), c.getY(), '0');
				return true;
			}
			else
				return false;
		}
		else
			return false;
	}
	
	public boolean valider_Grille()
	{
		if(grille.verifie_unicite() == true)
			return(true);
		else
			return false;
	}
}
