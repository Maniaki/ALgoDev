package AlgoDev.sudoku;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class MainSudokuFx extends Application{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}
	
	@Override
    public void start(Stage stage) throws Exception {
		FileInputStream inFileStream;
		File inFile = new File("Grille1.fic");
		inFileStream = new FileInputStream(inFile);
		inFile = new File("Grille1.fic");
		ObjectInputStream inObjectStream = new ObjectInputStream(inFileStream);
		Grille_sudoku grille = (Grille_sudoku) inObjectStream.readObject();
		inObjectStream.close();

		Text text2 = new Text();
		GridPane grid = new GridPane();
		
		grid.setGridLinesVisible(true);
		for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
            	TextField name = new TextField();
            	name.setMaxSize(40, 40);
            	name.setText(String.valueOf(grille.matrice[i][j]));
				name.setEditable(grille.matCoup[i][j]);
                grid.add(name,i,j);
}
}
		
	    grid.setScaleX(1);
	    grid.setScaleY(1);
	    grid.setScaleZ(1);	    
		
		grid.resizeRelocate(200,150 , 400, 400);
		
		Text text1 = new Text();
		//Taille du texte 
		text1.setFont(new Font(45));
		
		//zone ou le texte est afficher
		text1.setX(235);
		text1.setY(40);
		
		//couleur texte
		text1.setFill(Color.YELLOW);
		
		//ajouter bordure et couleur bordure texte
		
		text1.setStrokeWidth(2);
		text1.setStroke(Color.BLUE);
		
		//contenu du texte
		text1.setText("LE SUDOKU LETTRE");
		
		//cree un bouton 
	      Button btn= new Button("Sauvegarder"); 
	      btn.setLayoutX(150); 
	      btn.setLayoutY(550); 
	      
	      Button btn2= new Button("V�rification"); 
	      btn2.setLayoutX(400); 
	      btn2.setLayoutY(550); 
	      
	      Button btn3= new Button("Quitter"); 
	      btn3.setLayoutX(650); 
	      btn3.setLayoutY(550); 
	      
	      Button btn4= new Button("Nouvelle Partie"); 
	      btn4.setLayoutX(650); 
	      btn4.setLayoutY(150); 
	      
	      Button btn5= new Button("Charger"); 
	      btn5.setLayoutX(650); 
	      btn5.setLayoutY(250); 
	      
	      btn.setOnMouseClicked((new EventHandler<MouseEvent>() { // Sauvegarde
	    	  public void handle(MouseEvent event)
	    	  {
	    		  /// on recup dans un evenement 
	    		 int j=0;
	    		  int i=0;
	    		  for( Node node: grid.getChildren()) {

	                    if(( node instanceof TextField)&&((i!=8)&&(j!=8))&&(((TextField) node).getText()).isEmpty()==false) {
	                    	
	                       grille.matrice[i][j]=((TextField) node).getText().charAt(0);
	                       System.out.println(grille.matrice[i][j]);
	                       j=(j+1)%9;
	                       if(j==0)
	                       {
	                    	   i=(i+1);
	                    	   
	                       } 
	                    
	                }
	    		  }
	    	  File outFile = new File("SudokuSave.fic");
				try {
					FileOutputStream outFileStream = new FileOutputStream(outFile);
					ObjectOutputStream outObjectStream = new ObjectOutputStream(outFileStream);
					outObjectStream.writeObject(grille);
					outObjectStream.close();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
				
				//faire les modifs 
				
				
				 text2.setFont(new Font(25));
   			  text2.setX(300);
   			  text2.setY(500);
				  text2.setText("Sauvegard�");
				
	    	  }
	      }));
	      
	      btn2.setOnMouseClicked((new EventHandler<MouseEvent>(){ // Verification
	    	  public void handle(MouseEvent event) {
	    		  if(grille.verifie_unicite()==true)
	    		  {
	    			  if(grille.verifie_unicite()==true)
	    			  {
	    				  text2.setFont(new Font(25));
		    			  text2.setX(300);
		    			  text2.setY(500);
	    				  text2.setText("Vous avez Gagn�");
	    				  
	    			  }
	    			  else
	    			  {
	    				  text2.setFont(new Font(25));
		    			  text2.setX(255);
		    			  text2.setY(500);
	    				  text2.setText("Vous n'avez pas la bonne solution");
	    				  
	    			  }
	    		  }else
	    		  {
	    			  text2.setFont(new Font(25));
	    			  text2.setX(300);
	    			  text2.setY(500);
	    			  text2.setText("Vous n'avez pas fini");
	    			  
	    		  }
	    	  }
	      }));
	      
	      btn3.setOnMouseClicked((new EventHandler<MouseEvent>(){ //Quitter
	    	  public void handle(MouseEvent event) {
	    		  System.out.println("Au revoir");
	    		  stage.close();
	    	  }
	      }));
		
	      btn4.setOnMouseClicked((new EventHandler<MouseEvent>(){ //Nouvelle partie
	    	  public void handle(MouseEvent event) {
	    		//  grille.initializeGrid();
	    		  //grille.nouvelle_grille();
	    		  for(int k = 0;k<9;k++)
	    		  {
	    			  for(int l = 0; l<9;l++)
	    			  {
	    				  TextField name = new TextField();
	    				  name.setMaxSize(40, 40);
	    				  name.setText(String.valueOf(grille.matrice[k][l]));
	    				 
	    					name.setEditable(grille.matCoup[k][l]);
	    					 grid.add(name,k,l);
	    					 
	    				 
	    			  }
	    		  }
	    	  }
	      }));
		
	      btn5.setOnMouseClicked((new EventHandler<MouseEvent>(){ // Charger
	    	  public void handle(MouseEvent event) {
	    		  FileInputStream inFileStream;
	  			
					// Charger partie sauvegarder
					try {
					File inFile = new File("SudokuSave.fic");
					inFileStream = new FileInputStream(inFile);
					ObjectInputStream inObjectStream = new ObjectInputStream(inFileStream);
					Grille_sudoku grille = (Grille_sudoku) inObjectStream.readObject();
					inObjectStream.close();
					}catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					 for(int k = 0;k<9;k++)
		    		  {
		    			  for(int l = 0; l<9;l++)
		    			  {
		    				  TextField name = new TextField();
		    				  name.setMaxSize(40, 40);
		    				  name.setText(String.valueOf(grille.matrice[k][l]));
		    				 
		    					//name.setEditable(!grille.mat2[k][l]);
		    					 grid.add(name,k,l);
		    					 
		    				 
		    			  }
		    		  }
	    	    
					 text2.setFont(new Font(25));
	    			  text2.setX(300);
	    			  text2.setY(500);
	    			  text2.setText("Vous avez charg� la partie");
	    	  }}));
		
		Group root = new Group();

		//Retrieving the observable list object 
		//liste qu contient les btn et les textes
	      ObservableList list = root.getChildren(); 
	       
	      //Setting the text object as a node to the group object 
	      list.add(text1); 
	      list.add(btn);
	      list.add(btn2);
	      list.add(btn3);
	      list.add(btn4);
	      list.add(btn5);
	      list.add(text2);
		
	     list.add(grid);
	     
	     //creation de la scene
        Scene scene = new Scene(root,800,600);
        scene.setFill(Color.LAVENDER);  

        stage.setScene(scene);
        stage.setTitle("Le Sudoku Lettre");
        stage.setResizable(false);
       
        stage.show();
    }
		
}
