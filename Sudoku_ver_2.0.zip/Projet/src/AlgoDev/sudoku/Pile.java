package AlgoDev.sudoku;

import java.io.Serializable;
import java.util.ArrayList;

public class Pile implements Serializable{

	// Attribut
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected ArrayList<Coup> pile;
	protected int niveau;
	
	// Constructeur
	
	public Pile()
	{
		pile = new ArrayList<Coup>();
		niveau = -1;
	}

	// Getter Setter
	
	public ArrayList<Coup> getPile() {
		return pile;
	}

	public void setPile(ArrayList<Coup> pile) {
		this.pile = pile;
	}

	public int getNiveau() {
		return niveau;
	}

	public void setNiveau(int niveau) {
		this.niveau = niveau;
	}
	
	// Methode
	
	public void empile(Coup coup)
	{
		this.getPile().add(coup);
		this.setNiveau(this.getNiveau()+1);
	}
	
	public boolean depile()
	{
		if(this.getNiveau() >= 0)
		{
			this.getPile().remove(this.getNiveau());
			this.setNiveau(this.getNiveau()-1);
			return true;
		}
		else
			return false;
	}
	
}
