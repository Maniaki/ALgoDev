package AlgoDev.sudoku;

import java.io.Serializable;

public class Coup implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Atribut
	
	protected int x;
	protected int y;
	protected char symbole;
	
	// Constructeur
	
	public Coup(int x, int y, char symbole)
	{
		this.x = x;
		this.y = y;
		this.symbole = symbole;
	}

	// Getter Setter
	
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public char getSymbole() {
		return symbole;
	}

	public void setSymbole(char symbole) {
		this.symbole = symbole;
	}
	
	// Methode
	
}
